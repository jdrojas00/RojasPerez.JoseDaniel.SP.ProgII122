package model;

import java.io.Serializable;

public class Cancion implements Comparable<Cancion>, CSVSerializable, Serializable {

    private static final long serialVersionUID = 1L;
    private int id;
    private String titulo;
    private String artista;
    private GeneroMusical genero;

    public Cancion(int id, String titulo, String artista, GeneroMusical genero) {
        this.id = id;
        this.titulo = titulo;
        this.artista = artista;
        this.genero = genero;
    }

    public int getId() {
        return id;
    }

    public String getTitulo() {
        return titulo;
    }

    public String getArtista() {
        return artista;
    }

    public GeneroMusical getGenero() {
        return genero;
    }

    @Override
    public int compareTo(Cancion other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public String toCSV() {
        return id + "," + titulo + "," + artista + "," + genero;
    }

    public static Cancion fromCSV(String csv) {
        Cancion toReturn = null;
        if (csv.endsWith("\n")) {
            csv = csv.substring(0, csv.length() - 1);
        }
        String[] values = csv.split(",");
        if (values.length == 4) {

            int id = Integer.parseInt(values[0]);
            String titulo = values[1];
            String artista = values[2];
            GeneroMusical genero = GeneroMusical.valueOf(values[3]);
            toReturn = new Cancion(id, titulo, artista, genero);
        }
        return toReturn;
    }

    @Override
    public String toString() {
        return "Cancion{" + "id=" + id + ", titulo=" + titulo + ", artista=" + artista + ", genero=" + genero + '}';
    }
}

package config;

public class Rutas {
    public static final String RUTA_BINARIO = "src/data/canciones.dat";
    public static final String RUTA_CSV = "src/data/canciones.csv";
}
